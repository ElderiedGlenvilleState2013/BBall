//
//  PlayPositionCollectionViewCell.swift
//  Basketball
//
//  Created by McKinney family  on 3/25/18.
//  Copyright © 2018 FasTek Technologies. All rights reserved.
//

import UIKit

class PlayPositionCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var positionImage: UIImageView!
    
    @IBOutlet weak var skillLabel: UILabel!
    
   
    
    
    
}
